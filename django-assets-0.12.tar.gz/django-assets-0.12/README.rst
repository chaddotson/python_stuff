Integrates the `webassets`_ library with Django, adding support for
merging, minifying and compiling CSS and Javascript files.

Documentation:
    https://django-assets.readthedocs.io/

.. _webassets: http://github.com/miracle2k/webassets
